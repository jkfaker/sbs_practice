package org.example.dubbo.spring.demo;

public interface DemoService {
    String sayHello(String name);

    int getAddition(int a, int b);
}
